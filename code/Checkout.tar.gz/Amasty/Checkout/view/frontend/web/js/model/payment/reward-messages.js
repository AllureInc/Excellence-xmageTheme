
define([
    'Magento_Ui/js/model/messages'
], function (Messages) {
    'use strict';

    return new Messages();
});
